/*
 * touch.h
 *
 * Created: 10/02/2021 17:42:38
 *  Author: RafaelCF4
 */ 


#ifndef TOUCH_H_
#define TOUCH_H_

int readPoint(int *px, int *py);
void configure_touch(void);

#endif /* TOUCH_H_ */